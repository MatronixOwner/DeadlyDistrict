@echo off
start "" "%~dp0DeadlyDistrict-tester.exe" --safe
