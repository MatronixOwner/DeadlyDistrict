@echo off
start "" "%~dp0DeadlyDistrict.exe" --safe
